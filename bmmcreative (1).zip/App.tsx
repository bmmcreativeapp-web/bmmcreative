import React, { useState } from 'react';
import { Intro } from './components/Intro';
import { Hero } from './components/Hero';
import { Dashboard } from './components/Dashboard';
import { Services } from './components/Services';
import { WhyUs } from './components/WhyUs';
import { Pricing } from './components/Pricing';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { motion, AnimatePresence } from 'framer-motion';

const App: React.FC = () => {
  const [entered, setEntered] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="bg-white min-h-screen text-brand-black selection:bg-brand-black selection:text-white">
      <AnimatePresence>
        {!entered && <Intro onEnter={() => setEntered(true)} />}
      </AnimatePresence>

      {entered && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
        >
          {/* Navigation Bar (Floating & Clean) */}
          <nav className="fixed top-6 left-0 right-0 z-40 flex justify-center w-full px-4">
            <div className="bg-white/80 backdrop-blur-lg border border-gray-200 rounded-full px-6 md:px-8 py-3 flex items-center gap-4 md:gap-8 shadow-sm overflow-x-auto max-w-full">
               <button onClick={() => scrollToSection('home')} className="font-heading font-bold text-lg tracking-tight shrink-0">BMM Creative</button>
               <div className="hidden md:flex gap-6 text-sm font-body font-medium text-gray-600 whitespace-nowrap">
                  <button onClick={() => scrollToSection('home')} className="hover:text-brand-black transition-colors">Accueil</button>
                  <button onClick={() => scrollToSection('why-us')} className="hover:text-brand-black transition-colors">Pourquoi nous choisir</button>
                  <button onClick={() => scrollToSection('pricing')} className="hover:text-brand-black transition-colors">Nos Offres</button>
               </div>
               <button onClick={() => scrollToSection('contact')} className="px-5 py-2 bg-brand-black text-white text-xs font-bold font-heading rounded-full hover:bg-brand-charcoal transition-all shrink-0">
                 CONTACT
               </button>
            </div>
          </nav>

          <main>
            <Hero />
            <Dashboard />
            <Services />
            <WhyUs />
            <Pricing />
            <Contact />
          </main>
          <Footer />
        </motion.div>
      )}
    </div>
  );
};

export default App;
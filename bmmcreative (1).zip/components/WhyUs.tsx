import React from 'react';
import { motion } from 'framer-motion';
import { Utensils, ShoppingBag, Building2, CheckCircle2 } from 'lucide-react';

export const WhyUs: React.FC = () => {
  return (
    <section id="why-us" className="py-32 bg-brand-black text-white relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 right-0 w-[40rem] h-[40rem] bg-brand-charcoal rounded-full blur-3xl opacity-20 translate-x-1/2 -translate-y-1/2"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-20 max-w-4xl mx-auto">
            <h2 className="text-4xl lg:text-6xl font-heading font-bold mb-6 leading-tight">
              Expertise IA par <br/>
              <span className="text-gray-400">Secteur d'Activité</span>
            </h2>
            <p className="text-xl text-gray-400 font-body font-light">
              Notre agence adapte l'<strong>intelligence artificielle</strong> aux contraintes réelles de votre marché pour maximiser le ROI.
            </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
            {/* Restaurateurs */}
            <motion.div 
               initial={{ opacity: 0, y: 20 }}
               whileInView={{ opacity: 1, y: 0 }}
               transition={{ delay: 0 }}
               className="bg-white/5 border border-white/10 rounded-[2.5rem] p-8 hover:bg-white/10 transition-all duration-300"
            >
               <div className="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center mb-6 text-white">
                  <Utensils size={28} />
               </div>
               <h3 className="text-2xl font-heading font-bold mb-4">IA pour Restaurateurs</h3>
               <p className="text-gray-400 leading-relaxed mb-6">
                 Ne manquez plus jamais une réservation. Notre IA répond au téléphone, gère vos tables et répond aux avis Google 24/7.
               </p>
               <ul className="space-y-3 text-sm text-gray-300">
                  <li className="flex gap-2"><CheckCircle2 size={16} className="text-white"/> Booking Automatique</li>
                  <li className="flex gap-2"><CheckCircle2 size={16} className="text-white"/> Gestion E-Réputation</li>
               </ul>
            </motion.div>

            {/* E-commerce */}
            <motion.div 
               initial={{ opacity: 0, y: 20 }}
               whileInView={{ opacity: 1, y: 0 }}
               transition={{ delay: 0.2 }}
               className="bg-white rounded-[2.5rem] p-8 text-brand-black transform md:-translate-y-4 shadow-[0_0_50px_rgba(255,255,255,0.1)]"
            >
               <div className="w-14 h-14 bg-brand-black rounded-2xl flex items-center justify-center mb-6 text-white">
                  <ShoppingBag size={28} />
               </div>
               <h3 className="text-2xl font-heading font-bold mb-4">Automatisation E-commerce</h3>
               <p className="text-gray-600 leading-relaxed mb-6">
                 Augmentez votre panier moyen. L'IA recommande des produits, récupère les paniers abandonnés et gère le SAV instantanément.
               </p>
               <ul className="space-y-3 text-sm text-gray-800 font-medium">
                  <li className="flex gap-2"><CheckCircle2 size={16} /> Support Client IA 24/7</li>
                  <li className="flex gap-2"><CheckCircle2 size={16} /> Récupération Paniers</li>
               </ul>
            </motion.div>

            {/* Entreprises */}
            <motion.div 
               initial={{ opacity: 0, y: 20 }}
               whileInView={{ opacity: 1, y: 0 }}
               transition={{ delay: 0.4 }}
               className="bg-white/5 border border-white/10 rounded-[2.5rem] p-8 hover:bg-white/10 transition-all duration-300"
            >
               <div className="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center mb-6 text-white">
                  <Building2 size={28} />
               </div>
               <h3 className="text-2xl font-heading font-bold mb-4">Optimisation PME & B2B</h3>
               <p className="text-gray-400 leading-relaxed mb-6">
                 Streamlinez vos opérations. De la qualification de leads à la gestion administrative, libérez vos équipes avec des workflows intelligents.
               </p>
               <ul className="space-y-3 text-sm text-gray-300">
                  <li className="flex gap-2"><CheckCircle2 size={16} className="text-white"/> CRM Autonome (HubSpot/Salesforce)</li>
                  <li className="flex gap-2"><CheckCircle2 size={16} className="text-white"/> Qualification de Leads IA</li>
               </ul>
            </motion.div>
        </div>

        <div className="text-center max-w-2xl mx-auto">
             <p className="text-lg text-gray-500 italic">
               "Choisir BMM Creative, c'est choisir l'agence d'automatisation qui ne vend pas de la technologie, mais des résultats financiers."
             </p>
        </div>

      </div>
    </section>
  );
};
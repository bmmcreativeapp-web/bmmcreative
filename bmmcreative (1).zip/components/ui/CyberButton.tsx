import React from 'react';
import { motion } from 'framer-motion';

interface ButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
  variant?: 'primary' | 'secondary' | 'outline';
  type?: 'button' | 'submit';
}

export const CyberButton: React.FC<ButtonProps> = ({ 
  children, 
  onClick, 
  className = '', 
  variant = 'primary',
  type = 'button'
}) => {
  const variants = {
    primary: "bg-brand-black text-white hover:bg-brand-charcoal",
    secondary: "bg-brand-light text-brand-black hover:bg-gray-200",
    outline: "border border-brand-black text-brand-black hover:bg-brand-black hover:text-white"
  };

  return (
    <motion.button
      type={type}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={`
        relative px-8 py-4 font-heading font-medium text-sm rounded-full
        transition-colors duration-300 overflow-hidden flex items-center justify-center gap-2
        ${variants[variant]}
        ${className}
      `}
    >
      {children}
    </motion.button>
  );
};
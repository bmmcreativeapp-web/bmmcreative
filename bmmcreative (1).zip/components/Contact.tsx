import React from 'react';
import { motion } from 'framer-motion';
import { CyberButton } from './ui/CyberButton';

export const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-24 bg-brand-light flex items-center justify-center">
      <div className="container mx-auto px-6 w-full max-w-4xl">
        <motion.div 
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          className="bg-white p-8 md:p-16 rounded-[3rem] shadow-2xl shadow-gray-200/50"
        >
          <div className="text-center mb-12">
            <h2 className="text-4xl font-heading font-bold text-brand-black mb-4">Demander un Devis</h2>
            <p className="text-brand-gray">Remplissez le formulaire ci-dessous pour recevoir votre estimation personnalisée.</p>
          </div>
          
          {/* Formulaire Standard HTML pour garantir la réception des emails */}
          <form 
            action="https://formsubmit.co/bmmcreativeapp@gmail.com" 
            method="POST" 
            className="space-y-6"
          >
            {/* Configuration pour FormSubmit */}
            <input type="hidden" name="_subject" value="Nouveau Lead - Site Web BMM Creative" />
            <input type="hidden" name="_template" value="table" />
            <input type="hidden" name="_captcha" value="false" />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-brand-black ml-4">Nom Complet</label>
                <input 
                  required 
                  name="name" 
                  type="text" 
                  placeholder="Jean Dupont" 
                  className="w-full bg-brand-light border-none rounded-full px-6 py-4 text-brand-black focus:ring-2 focus:ring-brand-black focus:outline-none transition-all" 
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-brand-black ml-4">Nom de l'Entreprise</label>
                <input 
                  required 
                  name="company" 
                  type="text" 
                  placeholder="Votre Société" 
                  className="w-full bg-brand-light border-none rounded-full px-6 py-4 text-brand-black focus:ring-2 focus:ring-brand-black focus:outline-none transition-all" 
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               <div className="space-y-2">
                <label className="text-sm font-bold text-brand-black ml-4">Email Professionnel</label>
                <input 
                  required 
                  name="email" 
                  type="email" 
                  placeholder="contact@entreprise.com" 
                  className="w-full bg-brand-light border-none rounded-full px-6 py-4 text-brand-black focus:ring-2 focus:ring-brand-black focus:outline-none transition-all" 
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-brand-black ml-4">Objectif Principal</label>
                <select 
                  name="objective" 
                  className="w-full bg-brand-light border-none rounded-full px-6 py-4 text-brand-black focus:ring-2 focus:ring-brand-black focus:outline-none transition-all appearance-none cursor-pointer"
                >
                   <option value="Augmenter les Revenus">Augmenter les Revenus</option>
                   <option value="Gagner du Temps">Gagner du Temps</option>
                   <option value="Transformation Digitale">Transformation Digitale</option>
                   <option value="Autre">Autre</option>
                </select>
              </div>
            </div>

             <div className="space-y-2">
                <label className="text-sm font-bold text-brand-black ml-4">Détails du Projet</label>
                <textarea 
                  required 
                  name="message" 
                  rows={4} 
                  placeholder="Décrivez vos besoins actuels..." 
                  className="w-full bg-brand-light border-none rounded-[2rem] px-6 py-4 text-brand-black focus:ring-2 focus:ring-brand-black focus:outline-none transition-all resize-none"
                ></textarea>
              </div>

            <div className="pt-4 flex flex-col items-center gap-4">
              <CyberButton type="submit" className="w-full md:w-auto min-w-[200px]">
                Envoyer la demande
              </CyberButton>
              <p className="text-xs text-gray-400">
                 En cliquant sur Envoyer, vous acceptez d'être recontacté.
              </p>
            </div>
          </form>
        </motion.div>
      </div>
    </section>
  );
};
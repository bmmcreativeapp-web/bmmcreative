import React from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';
import { CyberButton } from './ui/CyberButton';

const offers = [
  {
    name: "Starter",
    desc: "L'automatisation essentielle pour démarrer.",
    features: ["Chatbot Basique", "Auto-Booking", "Scripts Simples", "Dashboard Lite"],
    highlight: false
  },
  {
    name: "Business",
    desc: "L'écosystème complet pour scaler.",
    features: ["Automatisation Complète", "Funnel Complet", "Dashboard Pro", "Séquences Email"],
    highlight: true,
    tag: "Recommandé"
  },
  {
    name: "Entreprise",
    desc: "Domination totale de votre marché.",
    features: ["Agents IA Custom", "Support Dédié", "Optimisation Mensuelle", "Accès Prioritaire"],
    highlight: false
  }
];

export const Pricing: React.FC = () => {
  return (
    <section id="pricing" className="py-32 bg-brand-light">
      <div className="container mx-auto px-6">
        <div className="text-center mb-20 max-w-3xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-heading font-bold text-brand-black mb-6">Nos Offres</h2>
          <p className="text-brand-gray text-lg font-body leading-relaxed">
            Des solutions adaptées à votre stade de croissance. Contactez-nous pour une étude personnalisée.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {offers.map((offer, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.2 }}
              className={`relative p-10 rounded-[2.5rem] flex flex-col transition-transform hover:-translate-y-2
                ${offer.highlight 
                  ? 'bg-brand-black text-white shadow-2xl' 
                  : 'bg-white text-brand-black shadow-lg border border-gray-100'}`}
            >
              {offer.highlight && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 px-6 py-2 bg-white text-brand-black font-bold text-sm tracking-wide rounded-full shadow-md">
                  {offer.tag}
                </div>
              )}
              
              <div className="mb-10">
                <h3 className="text-2xl font-heading font-bold mb-3">{offer.name}</h3>
                <p className={`text-sm ${offer.highlight ? 'text-gray-400' : 'text-gray-500'}`}>{offer.desc}</p>
              </div>

              <ul className="space-y-4 mb-10 flex-grow">
                {offer.features.map((feat, idx) => (
                  <li key={idx} className="flex items-start gap-3">
                    <div className={`p-1 rounded-full ${offer.highlight ? 'bg-white/20' : 'bg-brand-black/5'}`}>
                      <Check className="w-3 h-3" />
                    </div>
                    <span className="font-body text-sm font-medium">{feat}</span>
                  </li>
                ))}
              </ul>

              <CyberButton 
                variant={offer.highlight ? 'secondary' : 'outline'} 
                className={`w-full ${offer.highlight ? 'bg-white text-black hover:bg-gray-200' : ''}`}
                onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth'})}
              >
                Demander un Devis
              </CyberButton>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
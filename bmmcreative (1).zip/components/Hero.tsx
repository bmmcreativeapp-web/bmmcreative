import React from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { CyberButton } from './ui/CyberButton';
import { ArrowDown } from 'lucide-react';

export const Hero: React.FC = () => {
  const { scrollY } = useScroll();
  const y1 = useTransform(scrollY, [0, 500], [0, 100]);
  
  return (
    <section id="home" className="relative min-h-screen w-full flex items-center justify-center bg-brand-white pt-20 overflow-hidden">
      
      {/* Background Decor - Soft Organic Shapes */}
      <motion.div 
        animate={{ 
          scale: [1, 1.1, 1],
          rotate: [0, 5, -5, 0],
        }}
        transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
        className="absolute top-[-10%] right-[-5%] w-[600px] h-[600px] bg-brand-light rounded-full mix-blend-multiply filter blur-3xl opacity-60 pointer-events-none" 
      />
      <motion.div 
        animate={{ 
          scale: [1, 1.2, 1],
          x: [0, -30, 0],
        }}
        transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }}
        className="absolute bottom-[-10%] left-[-10%] w-[500px] h-[500px] bg-gray-100 rounded-full mix-blend-multiply filter blur-3xl opacity-60 pointer-events-none" 
      />

      <div className="container mx-auto px-6 z-10 relative flex flex-col items-center text-center">
        
        <motion.div style={{ y: y1 }} className="space-y-8 max-w-4xl">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="inline-flex items-center px-4 py-2 rounded-full bg-brand-black text-white"
          >
            <span className="font-heading font-medium text-sm tracking-wide">Agence IA N°1 & Automatisation</span>
          </motion.div>

          {/* H1 Optimisé SEO : Mots clés principaux inclus */}
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-6xl md:text-7xl lg:text-8xl font-heading font-bold text-brand-black leading-tight tracking-tight"
          >
            <span className="block text-2xl md:text-4xl mb-2 font-light text-brand-gray">BMM Creative</span>
            Automatisation IA <br/>& Business
          </motion.h1>

          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-brand-gray text-xl md:text-2xl font-body font-light max-w-2xl mx-auto leading-relaxed"
          >
            Nous construisons des <strong>systèmes d'intelligence artificielle</strong> capables d'automatiser votre business, générer des clients et augmenter vos revenus sans effort.
          </motion.h2>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 justify-center pt-8"
          >
            <CyberButton onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth'})}>
              Créer mon système IA
            </CyberButton>
            <CyberButton variant="secondary" onClick={() => document.getElementById('dashboard')?.scrollIntoView({ behavior: 'smooth'})}>
              Voir les résultats
            </CyberButton>
          </motion.div>
        </motion.div>
      </div>

      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 text-brand-gray animate-bounce"
      >
        <ArrowDown size={24} />
      </motion.div>
    </section>
  );
};
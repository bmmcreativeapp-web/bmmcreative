import React from 'react';
import { motion } from 'framer-motion';

const testimonials = [
  { name: "Alex R.", company: "TechFlow", text: "Immediate ROI. Our sales pipeline filled itself automatically.", role: "CEO" },
  { name: "Sarah L.", company: "ImmoPrestige", text: "We saved 20 hours a week. The chatbot qualifies better than humans.", role: "Founder" },
  { name: "David K.", company: "ScaleUp Agency", text: "Complexity made simple. BMMCreative is in a league of its own.", role: "Ops Director" }
];

export const Testimonials: React.FC = () => {
  return (
    <section className="py-24 bg-white overflow-hidden relative">
      <div className="container mx-auto px-6 relative z-10">
        <h2 className="text-center text-4xl font-heading font-bold mb-16 text-brand-black">
          Client <span className="text-brand-gray">Stories</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {testimonials.map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.2 }}
              className="bg-brand-light p-10 rounded-[3rem] rounded-tl-none relative hover:shadow-lg transition-shadow duration-300"
            >
              <div className="mb-6">
                <p className="text-brand-black font-body text-lg leading-relaxed">"{t.text}"</p>
              </div>
              
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-brand-black rounded-full flex items-center justify-center text-white font-bold font-heading">
                  {t.name[0]}
                </div>
                <div>
                  <h4 className="font-bold text-brand-black font-heading">{t.name}</h4>
                  <p className="text-xs text-brand-gray uppercase tracking-wider">{t.role} - {t.company}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
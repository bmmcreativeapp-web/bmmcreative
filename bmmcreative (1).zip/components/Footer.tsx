import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-black text-white py-16 rounded-t-[3rem] mt-[-2rem] relative z-20">
      <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
        <div className="flex flex-col items-center md:items-start gap-2">
            <span className="text-3xl font-heading font-bold">BMM Creative</span>
            <span className="text-gray-500 text-sm">© 2024. Innovation Authentique.</span>
            <a href="mailto:bmmcreativeapp@gmail.com" className="text-gray-400 text-sm hover:text-white transition-colors mt-2">
              bmmcreativeapp@gmail.com
            </a>
        </div>
        
        <div className="flex gap-8 text-sm font-body text-gray-400">
          <a href="#" className="hover:text-white transition-colors">Mentions Légales</a>
          <a href="#" className="hover:text-white transition-colors">Confidentialité</a>
          <a href="#contact" className="hover:text-white transition-colors">Contact</a>
        </div>
      </div>
    </footer>
  );
};
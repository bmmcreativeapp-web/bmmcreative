import React from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, GitMerge, Mail, Calendar, TrendingUp, Cpu } from 'lucide-react';

const services = [
  { 
    title: "Chatbots IA Vendeurs", 
    desc: "Agents conversationnels 24/7 entraînés sur vos données pour engager, supporter et vendre automatiquement.", 
    icon: MessageCircle 
  },
  { 
    title: "Automatisation Make & Zapier", 
    desc: "Création de workflows complexes pour connecter vos applications et supprimer les tâches manuelles.", 
    icon: GitMerge 
  },
  { 
    title: "Outreach & Emailing IA", 
    desc: "Systèmes de prospection intelligents générant des leads qualifiés via séquences emails et messages personnalisés.", 
    icon: Mail 
  },
  { 
    title: "Prise de RDV Automatisée", 
    desc: "Système de booking autonome synchronisé avec votre calendrier pour remplir votre agenda sans intervention.", 
    icon: Calendar 
  },
  { 
    title: "Business Intelligence & Data", 
    desc: "Tableaux de bord automatisés pour piloter votre croissance avec des données précises en temps réel.", 
    icon: TrendingUp 
  },
  { 
    title: "Solutions IA Sur-Mesure", 
    desc: "Développement d'algorithmes et intégration d'API OpenAI/GPT-4 taillés pour vos processus métier.", 
    icon: Cpu 
  },
];

export const Services: React.FC = () => {
  return (
    <section id="services" className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="mb-20 text-center max-w-2xl mx-auto">
          <span className="inline-block px-4 py-1 rounded-full bg-brand-light text-brand-black text-xs font-bold tracking-widest uppercase mb-4">
            Nos Systèmes IA
          </span>
          <h2 className="text-4xl md:text-5xl font-heading font-bold text-brand-black mb-6">
            Services d'Automatisation Business
          </h2>
          <p className="text-brand-gray text-lg font-body">
            En tant qu'<strong>agence d'automatisation IA</strong>, nous bâtissons l'infrastructure technologique de votre succès pour une croissance systématique.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              whileHover={{ y: -5 }}
              className="group p-10 bg-brand-light rounded-[2.5rem] hover:bg-brand-black transition-all duration-300"
            >
              <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mb-8 shadow-sm group-hover:bg-brand-charcoal transition-colors">
                <service.icon className="text-brand-black group-hover:text-white transition-colors" size={28} />
              </div>
              
              <h3 className="text-xl font-heading font-bold text-brand-black mb-4 group-hover:text-white transition-colors">
                {service.title}
              </h3>
              <p className="text-brand-gray font-body leading-relaxed group-hover:text-gray-400 transition-colors">
                {service.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
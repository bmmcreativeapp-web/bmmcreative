import React, { useState, useEffect } from 'react';
import { Intro } from './components/Intro';
import { Hero } from './components/Hero';
import { Dashboard } from './components/Dashboard';
import { Services } from './components/Services';
import { WhyUs } from './components/WhyUs';
import { Pricing } from './components/Pricing';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import Logo from './components/Logo';
import { ConsentBanner } from './components/ConsentBanner';
import { motion, AnimatePresence } from 'framer-motion';
import { Sun, Moon } from 'lucide-react';

const App: React.FC = () => {
  const [entered, setEntered] = useState(false);
  // Default to dark mode based on previous preference, but user can toggle
  const [isDark, setIsDark] = useState(true);

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  const toggleTheme = () => setIsDark(!isDark);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="bg-gray-50 dark:bg-[#050505] min-h-screen text-gray-900 dark:text-white selection:bg-black selection:text-white dark:selection:bg-white dark:selection:text-black transition-colors duration-500">
      
      {/* Analytics & Compliance */}
      <ConsentBanner />

      <AnimatePresence>
        {!entered && <Intro onEnter={() => setEntered(true)} />}
      </AnimatePresence>

      {entered && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
        >
          {/* Navigation Bar */}
          <nav className="fixed top-6 left-0 right-0 z-40 flex justify-center w-full px-4">
            <div className="bg-white/80 dark:bg-[#111111]/80 backdrop-blur-lg border border-gray-200 dark:border-white/10 rounded-full px-6 md:px-8 py-3 flex items-center gap-4 md:gap-8 shadow-lg dark:shadow-[0_0_20px_rgba(0,0,0,0.5)] overflow-x-auto max-w-full transition-all duration-500">
               <button onClick={() => scrollToSection('home')} className="flex items-center gap-2 font-heading font-bold text-lg tracking-tight shrink-0 text-gray-900 dark:text-white transition-colors">
                 <Logo className="w-6 h-6" />
                 <span>BMM Creative</span>
               </button>
               <div className="hidden md:flex gap-6 text-sm font-body font-medium text-gray-600 dark:text-gray-400 whitespace-nowrap">
                  <button onClick={() => scrollToSection('home')} className="hover:text-black dark:hover:text-white transition-colors">Accueil</button>
                  <button onClick={() => scrollToSection('why-us')} className="hover:text-black dark:hover:text-white transition-colors">Pourquoi nous choisir</button>
                  <button onClick={() => scrollToSection('pricing')} className="hover:text-black dark:hover:text-white transition-colors">Nos Offres</button>
               </div>
               
               <div className="flex items-center gap-3 shrink-0">
                 <button 
                   onClick={toggleTheme} 
                   className="p-2 rounded-full bg-gray-100 dark:bg-white/10 text-gray-700 dark:text-white hover:bg-gray-200 dark:hover:bg-white/20 transition-all"
                   aria-label="Toggle Theme"
                 >
                   {isDark ? <Sun size={18} /> : <Moon size={18} />}
                 </button>
                 
                 <button onClick={() => scrollToSection('contact')} className="px-5 py-2 bg-black dark:bg-white text-white dark:text-black text-xs font-bold font-heading rounded-full hover:bg-gray-800 dark:hover:bg-gray-200 transition-all">
                   CONTACT
                 </button>
               </div>
            </div>
          </nav>

          <main>
            <Hero />
            <Dashboard isDark={isDark} />
            <Services />
            <WhyUs />
            <Pricing />
            <Contact />
          </main>
          
          <Footer />
        </motion.div>
      )}
    </div>
  );
};

export default App;
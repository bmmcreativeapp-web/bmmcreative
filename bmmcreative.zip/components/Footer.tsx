import React from 'react';
import Logo from './Logo';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-100 dark:bg-black text-gray-900 dark:text-white py-16 relative z-20 border-t border-gray-200 dark:border-white/5 transition-colors duration-500">
      <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
        <div className="flex flex-col items-center md:items-start gap-2">
            <div className="flex items-center gap-2">
              <Logo className="w-8 h-8" />
              <span className="text-3xl font-heading font-bold tracking-tight text-black dark:text-white">BMM Creative</span>
            </div>
            <span className="text-gray-500 text-sm">© 2024. Innovation Authentique.</span>
            <a href="mailto:bmmcreativeapp@gmail.com" className="text-gray-600 dark:text-gray-400 text-sm hover:text-black dark:hover:text-white transition-colors mt-2">
              bmmcreativeapp@gmail.com
            </a>
        </div>
        
        <div className="flex gap-8 text-sm font-body text-gray-600 dark:text-gray-400">
          <a href="#" className="hover:text-black dark:hover:text-white transition-colors">Mentions Légales</a>
          <a href="#" className="hover:text-black dark:hover:text-white transition-colors">Confidentialité</a>
          <a href="#contact" className="hover:text-black dark:hover:text-white transition-colors">Contact</a>
        </div>
      </div>
    </footer>
  );
};
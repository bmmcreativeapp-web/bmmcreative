import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import Logo from './Logo';

interface IntroProps {
  onEnter: () => void;
}

export const Intro: React.FC<IntroProps> = ({ onEnter }) => {
  const [isExiting, setIsExiting] = useState(false);
  const [isDark, setIsDark] = useState(true);

  // Check initial theme to style intro correctly
  useEffect(() => {
    if (document.documentElement.classList.contains('dark')) {
      setIsDark(true);
    } else {
      setIsDark(false); // Default logic
    }
  }, []);

  const handleEnter = () => {
    setIsExiting(true);
    setTimeout(onEnter, 1000);
  };

  return (
    <motion.div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-white dark:bg-[#050505] overflow-hidden transition-colors duration-500"
      exit={{ opacity: 0, transition: { duration: 0.8, ease: "easeInOut" } }}
    >
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(0,0,0,0.03)_0%,_transparent_70%)] dark:bg-[radial-gradient(circle_at_center,_rgba(255,255,255,0.03)_0%,_transparent_70%)]"></div>
      
      <AnimatePresence>
        {!isExiting && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20, transition: { duration: 0.5 } }}
            transition={{ duration: 0.8 }}
            className="relative z-10 flex flex-col items-center justify-center max-w-md text-center px-6"
          >
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.8 }}
              className="mb-8 flex flex-col items-center"
            >
              <Logo className="w-20 h-20 mb-6" />
              <h1 className="text-4xl md:text-5xl font-heading font-bold text-black dark:text-white tracking-tight mb-2">
                BMM Creative
              </h1>
              <div className="h-[1px] w-24 bg-gradient-to-r from-transparent via-black dark:via-white to-transparent mx-auto"></div>
            </motion.div>

            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.8 }}
              className="text-gray-600 dark:text-gray-400 font-body font-light mb-12 text-lg tracking-wide"
            >
              Futur. Intelligence. Élégance.
            </motion.p>

            <motion.button
              onClick={handleEnter}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="group flex items-center gap-3 px-8 py-4 bg-transparent border border-gray-300 dark:border-white/20 text-black dark:text-white rounded-full font-heading font-medium hover:bg-black hover:text-white dark:hover:bg-white dark:hover:text-black transition-all duration-300"
            >
              <span>Entrer</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
import React from 'react';
import { motion } from 'framer-motion';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const growthData = [
  { name: 'Mois 1', standard: 2.5, automated: 3.2 },
  { name: 'Mois 2', standard: 2.6, automated: 4.5 },
  { name: 'Mois 3', standard: 2.7, automated: 6.8 },
  { name: 'Mois 4', standard: 2.8, automated: 9.5 },
  { name: 'Mois 5', standard: 2.9, automated: 12.4 },
  { name: 'Mois 6', standard: 3.0, automated: 16.0 },
];

interface DashboardProps {
  isDark: boolean;
}

export const Dashboard: React.FC<DashboardProps> = ({ isDark }) => {
  return (
    <section id="dashboard" className="py-24 bg-white dark:bg-[#050505] relative transition-colors duration-500">
      <div className="container mx-auto px-6">
        <div className="mb-16 md:text-center max-w-3xl mx-auto">
          <span className="inline-block px-4 py-1 rounded-full bg-gray-100 dark:bg-white/10 border border-gray-200 dark:border-white/10 text-gray-700 dark:text-white text-xs font-bold tracking-widest uppercase mb-4">
            Projection de Croissance
          </span>
          <h2 className="text-4xl md:text-5xl font-heading font-bold text-gray-900 dark:text-white mb-6">
            Accélération par <span className="text-gray-500">l'IA</span>
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-400 font-body">
            L'automatisation ne se contente pas de maintenir votre activité : elle optimise chaque interaction pour maximiser votre taux de conversion mois après mois.
          </p>
        </div>

        {/* Main Dashboard Container */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="bg-white dark:bg-[#111111] rounded-[3rem] p-6 md:p-12 shadow-2xl border border-gray-200 dark:border-white/5 max-w-5xl mx-auto relative overflow-hidden transition-colors duration-500"
        >
            <div className="absolute top-0 right-0 w-[300px] h-[300px] bg-purple-500/5 rounded-full blur-3xl pointer-events-none"></div>

            {/* Main Chart: Growth Comparison */}
            <div className="bg-gray-50 dark:bg-[#0A0A0A] rounded-[2.5rem] p-8 border border-gray-100 dark:border-white/5 relative z-10 transition-colors duration-500">
               <div className="flex justify-between items-center mb-8 flex-wrap gap-4">
                  <div>
                    <h4 className="text-xl font-heading font-bold text-gray-900 dark:text-white">Évolution du Taux de Conversion</h4>
                    <p className="text-sm text-gray-500">Comparaison : Performance Standard vs Optimisation IA</p>
                  </div>
                  <div className="flex gap-4 text-xs font-bold">
                    <span className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-gray-400 dark:bg-gray-700"></div>Standard</span>
                    <span className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-black dark:bg-white"></div>BMM Auto</span>
                  </div>
               </div>
               <div className="h-[400px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={growthData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                      <defs>
                        <linearGradient id="colorAuto" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor={isDark ? "#FFFFFF" : "#000000"} stopOpacity={0.2}/>
                          <stop offset="95%" stopColor={isDark ? "#FFFFFF" : "#000000"} stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isDark ? "#222" : "#eee"} />
                      <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#888', fontSize: 12}} dy={10} />
                      <YAxis axisLine={false} tickLine={false} tick={{fill: '#888', fontSize: 12}} tickFormatter={(value) => `${value}%`} />
                      <Tooltip 
                        formatter={(value: number) => [`${value}%`, 'Taux de conv.']}
                        contentStyle={{ 
                          backgroundColor: isDark ? '#1A1A1A' : '#FFFFFF', 
                          borderRadius: '16px', 
                          border: isDark ? '1px solid #333' : '1px solid #eee', 
                          color: isDark ? '#fff' : '#000',
                          boxShadow: '0 10px 30px rgba(0,0,0,0.1)'
                        }}
                        itemStyle={{ color: isDark ? '#fff' : '#000' }}
                      />
                      <Area type="monotone" dataKey="standard" stroke="#888" strokeWidth={2} fill="transparent" strokeDasharray="5 5" />
                      <Area type="monotone" dataKey="automated" stroke={isDark ? "#FFFFFF" : "#000000"} strokeWidth={3} fill="url(#colorAuto)" />
                    </AreaChart>
                  </ResponsiveContainer>
               </div>
            </div>
        </motion.div>
      </div>
    </section>
  );
};
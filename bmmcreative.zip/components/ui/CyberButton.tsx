import React from 'react';
import { motion } from 'framer-motion';

interface ButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
  variant?: 'primary' | 'secondary' | 'outline';
  type?: 'button' | 'submit';
}

export const CyberButton: React.FC<ButtonProps> = ({ 
  children, 
  onClick, 
  className = '', 
  variant = 'primary',
  type = 'button'
}) => {
  const variants = {
    primary: "bg-black text-white hover:bg-gray-800 border border-black shadow-lg dark:bg-white dark:text-black dark:hover:bg-gray-200 dark:border-white dark:shadow-[0_0_15px_rgba(255,255,255,0.3)]",
    secondary: "bg-white text-black border border-gray-200 hover:bg-gray-50 dark:bg-transparent dark:text-white dark:border-white/20 dark:hover:bg-white/10 dark:hover:border-white/50 backdrop-blur-sm",
    outline: "border border-gray-300 text-gray-600 hover:text-black hover:border-black dark:border-white/20 dark:text-gray-300 dark:hover:text-white dark:hover:border-white"
  };

  return (
    <motion.button
      type={type}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={`
        relative px-8 py-4 font-heading font-medium text-sm rounded-full
        transition-all duration-300 overflow-hidden flex items-center justify-center gap-2
        ${variants[variant]}
        ${className}
      `}
    >
      {children}
    </motion.button>
  );
};
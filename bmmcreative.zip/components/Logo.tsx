import React from 'react';

export const Logo: React.FC<{ className?: string }> = ({ className = "w-8 h-8" }) => (
  <svg 
    viewBox="0 0 100 100" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg" 
    className={className}
    aria-label="BMM Creative Logo"
  >
    {/* Three diagonal bars with rounded caps */}
    <path 
      d="M25 85 L65 45" 
      stroke="#3B82F6" 
      strokeWidth="14" 
      strokeLinecap="round"
      className="drop-shadow-sm"
    />
    <path 
      d="M45 65 L85 25" 
      stroke="#3B82F6" 
      strokeWidth="14" 
      strokeLinecap="round"
      className="drop-shadow-sm"
    />
    <path 
      d="M35 100 L95 40" 
      stroke="#3B82F6" 
      strokeWidth="14" 
      strokeLinecap="round"
      className="drop-shadow-sm hidden"
    /> 
    {/* Corrected 3-bar layout based on standard tech logos */}
    <line x1="20" y1="80" x2="50" y2="50" stroke="#3B82F6" strokeWidth="12" strokeLinecap="round" />
    <line x1="40" y1="80" x2="70" y2="50" stroke="#3B82F6" strokeWidth="12" strokeLinecap="round" />
    <line x1="60" y1="80" x2="90" y2="50" stroke="#3B82F6" strokeWidth="12" strokeLinecap="round" />
  </svg>
);

// Redesigning the path to be cleaner and exactly 3 parallel bars
export const LogoClean: React.FC<{ className?: string }> = ({ className = "w-8 h-8" }) => (
  <svg 
    viewBox="0 0 100 100" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg" 
    className={className}
  >
    <path 
      d="M20 75 L55 40" 
      stroke="#3B82F6" 
      strokeWidth="12" 
      strokeLinecap="round"
    />
    <path 
      d="M38 75 L73 40" 
      stroke="#3B82F6" 
      strokeWidth="12" 
      strokeLinecap="round"
    />
    <path 
      d="M56 75 L91 40" 
      stroke="#3B82F6" 
      strokeWidth="12" 
      strokeLinecap="round"
    />
  </svg>
);

// Exporting the primary one used
export default LogoClean;
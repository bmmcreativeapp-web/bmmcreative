import React from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, GitMerge, Mail, Calendar, TrendingUp, Cpu } from 'lucide-react';

const services = [
  { 
    title: "Intégration Chatbot IA", 
    desc: "Déploiement d'agents conversationnels intelligents pour automatiser le support et les ventes 24/7.", 
    icon: MessageCircle 
  },
  { 
    title: "AI Automation & Workflows", 
    desc: "Optimisation des processus via Make & Zapier pour connecter vos outils et éliminer les tâches répétitives.", 
    icon: GitMerge 
  },
  { 
    title: "Outreach & Lead Gen IA", 
    desc: "Systèmes de prospection automatisés générant des leads qualifiés via séquences emails et messages personnalisés.", 
    icon: Mail 
  },
  { 
    title: "Optimisation de Planning", 
    desc: "Système de booking autonome synchronisé avec votre calendrier pour remplir votre agenda sans intervention.", 
    icon: Calendar 
  },
  { 
    title: "Business Intelligence & Data", 
    desc: "Tableaux de bord automatisés pour piloter votre croissance avec des données précises en temps réel.", 
    icon: TrendingUp 
  },
  { 
    title: "Solutions IA Custom", 
    desc: "Développement d'algorithmes et intégration d'API OpenAI/GPT-4 taillés pour vos processus métier.", 
    icon: Cpu 
  },
];

export const Services: React.FC = () => {
  return (
    <section id="services" className="py-24 bg-gray-50 dark:bg-[#050505] transition-colors duration-500">
      <div className="container mx-auto px-6">
        <div className="mb-20 text-center max-w-2xl mx-auto">
          <span className="inline-block px-4 py-1 rounded-full bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 text-gray-600 dark:text-gray-300 text-xs font-bold tracking-widest uppercase mb-4 shadow-sm dark:shadow-none">
            Nos Systèmes IA
          </span>
          <h2 className="text-4xl md:text-5xl font-heading font-bold text-gray-900 dark:text-white mb-6">
            Services d'Automatisation
          </h2>
          <p className="text-gray-600 dark:text-gray-400 text-lg font-body">
            Nous proposons des services d'<strong>AI Automation</strong> et d'<strong>Intégration Chatbot</strong> pour garantir une optimisation totale de vos revenus.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              whileHover={{ y: -5 }}
              className="group p-10 bg-white dark:bg-[#111111] border border-gray-200 dark:border-white/5 rounded-[2.5rem] hover:shadow-xl dark:hover:bg-[#161616] dark:hover:border-white/20 transition-all duration-300"
            >
              <div className="w-16 h-16 bg-gray-100 dark:bg-white/5 rounded-2xl flex items-center justify-center mb-8 shadow-sm group-hover:bg-black dark:group-hover:bg-white transition-colors border border-gray-200 dark:border-white/10">
                <service.icon className="text-black dark:text-white group-hover:text-white dark:group-hover:text-black transition-colors" size={28} />
              </div>
              
              <h3 className="text-xl font-heading font-bold text-gray-900 dark:text-white mb-4">
                {service.title}
              </h3>
              <p className="text-gray-600 dark:text-gray-500 font-body leading-relaxed group-hover:text-gray-900 dark:group-hover:text-gray-300 transition-colors">
                {service.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
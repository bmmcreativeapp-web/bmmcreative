import React from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';
import { CyberButton } from './ui/CyberButton';

const offers = [
  {
    name: "Starter",
    desc: "L'automatisation essentielle pour démarrer.",
    features: ["Chatbot Basique", "Auto-Booking", "Scripts Simples", "Dashboard Lite"],
    highlight: false
  },
  {
    name: "Business",
    desc: "L'écosystème complet pour scaler.",
    features: ["Automatisation Complète", "Funnel Complet", "Dashboard Pro", "Séquences Email"],
    highlight: true,
    tag: "Recommandé"
  },
  {
    name: "Entreprise",
    desc: "Domination totale de votre marché.",
    features: ["Agents IA Custom", "Support Dédié", "Optimisation Mensuelle", "Accès Prioritaire"],
    highlight: false
  }
];

export const Pricing: React.FC = () => {
  return (
    <section id="pricing" className="py-32 bg-gray-50 dark:bg-[#050505] transition-colors duration-500">
      <div className="container mx-auto px-6">
        <div className="text-center mb-20 max-w-3xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-heading font-bold text-gray-900 dark:text-white mb-6">Nos Offres</h2>
          <p className="text-gray-600 dark:text-gray-400 text-lg font-body leading-relaxed">
            Des solutions adaptées à votre stade de croissance. Contactez-nous pour une étude personnalisée.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {offers.map((offer, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.2 }}
              className={`relative p-10 rounded-[2.5rem] flex flex-col transition-all hover:-translate-y-2
                ${offer.highlight 
                  ? 'bg-black text-white dark:bg-white dark:text-black shadow-2xl dark:shadow-[0_0_40px_rgba(255,255,255,0.1)]' 
                  : 'bg-white text-black dark:bg-[#111] dark:text-white border border-gray-200 dark:border-white/10 shadow-lg dark:shadow-none'}`}
            >
              {offer.highlight && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 px-6 py-2 bg-white text-black dark:bg-black dark:text-white font-bold text-sm tracking-wide rounded-full border border-gray-200 dark:border-white/20 shadow-md">
                  {offer.tag}
                </div>
              )}
              
              <div className="mb-10">
                <h3 className="text-2xl font-heading font-bold mb-3">{offer.name}</h3>
                <p className={`text-sm ${offer.highlight ? 'text-gray-400 dark:text-gray-600' : 'text-gray-500'}`}>{offer.desc}</p>
              </div>

              <ul className="space-y-4 mb-10 flex-grow">
                {offer.features.map((feat, idx) => (
                  <li key={idx} className="flex items-start gap-3">
                    <div className={`p-1 rounded-full ${offer.highlight ? 'bg-white/10 dark:bg-black/10' : 'bg-black/5 dark:bg-white/10'}`}>
                      <Check className="w-3 h-3" />
                    </div>
                    <span className="font-body text-sm font-medium">{feat}</span>
                  </li>
                ))}
              </ul>

              <CyberButton 
                variant={offer.highlight ? 'primary' : 'outline'} 
                className={`w-full ${offer.highlight ? '!bg-white !text-black dark:!bg-black dark:!text-white dark:!border-black' : 'dark:!border-white/20'}`}
                onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth'})}
              >
                Demander un Devis
              </CyberButton>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
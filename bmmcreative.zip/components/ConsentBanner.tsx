import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Cookie, Check } from 'lucide-react';

declare global {
  interface Window {
    gtag: (...args: any[]) => void;
  }
}

export const ConsentBanner: React.FC = () => {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('consentMode');
    if (!consent) {
      const timer = setTimeout(() => setShow(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleConsent = (granted: boolean) => {
    const consentState = {
      'ad_storage': granted ? 'granted' : 'denied',
      'ad_user_data': granted ? 'granted' : 'denied',
      'ad_personalization': granted ? 'granted' : 'denied',
      'analytics_storage': granted ? 'granted' : 'denied'
    };
    
    localStorage.setItem('consentMode', JSON.stringify(consentState));
    
    if (window.gtag) {
      window.gtag('consent', 'update', consentState);
    }
    
    setShow(false);
  };

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="fixed bottom-6 left-4 right-4 md:left-8 md:right-8 z-50 flex justify-center pointer-events-none"
        >
          <div className="pointer-events-auto bg-[#111111]/90 backdrop-blur-xl p-6 md:p-8 rounded-[2rem] shadow-2xl border border-white/10 max-w-3xl w-full flex flex-col md:flex-row items-center gap-6 md:gap-8">
             <div className="p-4 bg-white/5 rounded-2xl shrink-0 border border-white/5 hidden md:block">
               <Cookie className="text-white" size={28} />
             </div>
             
             <div className="flex-1 text-center md:text-left space-y-2">
               <h3 className="font-heading font-bold text-xl text-white">Confidentialité & Données</h3>
               <p className="text-gray-400 text-sm font-body leading-relaxed">
                 Nous utilisons des technologies de suivi avancées pour optimiser nos systèmes d'IA et analyser l'audience.
               </p>
             </div>

             <div className="flex gap-4 shrink-0 w-full md:w-auto">
               <button 
                 onClick={() => handleConsent(false)}
                 className="flex-1 md:flex-none px-6 py-3 rounded-full border border-white/20 text-gray-300 hover:bg-white/5 hover:text-white hover:border-white font-medium text-sm transition-all duration-300"
               >
                 Refuser
               </button>
               <button 
                 onClick={() => handleConsent(true)}
                 className="flex-1 md:flex-none px-8 py-3 rounded-full bg-white text-black font-heading font-bold text-sm hover:bg-gray-200 hover:scale-105 transition-all duration-300 flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(255,255,255,0.3)]"
               >
                 <Check size={16} />
                 Accepter
               </button>
             </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
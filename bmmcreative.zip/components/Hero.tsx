import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Bot, Cpu, Zap } from 'lucide-react';
import { CyberButton } from './ui/CyberButton';

export const Hero: React.FC = () => {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden bg-gray-50 dark:bg-[#050505] transition-colors duration-500">
      {/* Background Ambience */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[50vw] h-[50vw] bg-purple-200/40 dark:bg-purple-900/20 rounded-full blur-[120px] opacity-30 animate-pulse-slow"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[50vw] h-[50vw] bg-blue-200/40 dark:bg-blue-900/20 rounded-full blur-[120px] opacity-30 animate-pulse-slow delay-1000"></div>
        <div className="absolute top-[40%] left-[50%] transform -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] border border-black/5 dark:border-white/5 rounded-full opacity-20"></div>
        <div className="absolute top-[40%] left-[50%] transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] border border-black/5 dark:border-white/5 rounded-full opacity-20"></div>
      </div>

      <div className="container mx-auto px-6 relative z-10 text-center">
        {/* Badge */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 mb-8 backdrop-blur-sm shadow-sm dark:shadow-none"
        >
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
          <span className="text-xs font-bold tracking-widest uppercase text-gray-600 dark:text-gray-300">Agence IA Certifiée</span>
        </motion.div>

        {/* Main Title */}
        <motion.h1 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-5xl md:text-7xl lg:text-8xl font-heading font-bold text-gray-900 dark:text-white mb-8 tracking-tight leading-none"
        >
          L'Automatisation <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-600 to-gray-900 dark:from-gray-100 dark:to-gray-600">Intelligente</span>
        </motion.h1>

        {/* Description */}
        <motion.p 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-lg md:text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto mb-12 font-light leading-relaxed"
        >
          Nous transformons les entreprises en machines de croissance autonomes grâce à l'Intelligence Artificielle. Gagnez du temps. Maximisez vos revenus.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col md:flex-row items-center justify-center gap-6"
        >
          <CyberButton onClick={scrollToContact} variant="primary">
            Lancer l'Audit Gratuit
            <ArrowRight size={18} />
          </CyberButton>
          <CyberButton onClick={() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth'})} variant="secondary">
            Découvrir nos solutions
          </CyberButton>
        </motion.div>

        {/* Floating Icons Animation */}
        <div className="absolute top-1/2 left-0 w-full h-full pointer-events-none -z-10 hidden md:block">
           <motion.div animate={{ y: [-10, 10, -10] }} transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }} className="absolute top-20 left-[15%] text-gray-400 dark:text-gray-700 opacity-30 dark:opacity-20"><Bot size={48} /></motion.div>
           <motion.div animate={{ y: [15, -15, 15] }} transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }} className="absolute bottom-40 right-[15%] text-gray-400 dark:text-gray-700 opacity-30 dark:opacity-20"><Cpu size={64} /></motion.div>
           <motion.div animate={{ y: [-20, 20, -20] }} transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }} className="absolute top-40 right-[25%] text-gray-400 dark:text-gray-700 opacity-30 dark:opacity-20"><Zap size={32} /></motion.div>
        </div>
      </div>
    </section>
  );
};
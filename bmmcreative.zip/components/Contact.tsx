import React from 'react';
import { motion } from 'framer-motion';
import { CyberButton } from './ui/CyberButton';

export const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-24 bg-white dark:bg-[#050505] flex items-center justify-center relative overflow-hidden transition-colors duration-500">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gray-100 dark:bg-white/5 rounded-full blur-[100px] opacity-50 dark:opacity-20"></div>
      </div>

      <div className="container mx-auto px-6 w-full max-w-4xl relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          className="bg-gray-50 dark:bg-[#111] p-8 md:p-16 rounded-[3rem] border border-gray-200 dark:border-white/10 shadow-2xl transition-colors duration-500"
        >
          <div className="text-center mb-12">
            <h2 className="text-4xl font-heading font-bold text-gray-900 dark:text-white mb-4">Demander un Devis</h2>
            <p className="text-gray-600 dark:text-gray-400">Remplissez le formulaire ci-dessous pour recevoir votre estimation personnalisée.</p>
          </div>
          
          <form 
            action="https://formsubmit.co/bmmcreativeapp@gmail.com" 
            method="POST" 
            className="space-y-6"
          >
            <input type="hidden" name="_subject" value="Nouveau Lead - Site Web BMM Creative" />
            <input type="hidden" name="_template" value="table" />
            <input type="hidden" name="_captcha" value="false" />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-800 dark:text-white ml-4">Nom Complet</label>
                <input 
                  required 
                  name="name" 
                  type="text" 
                  placeholder="Jean Dupont" 
                  className="w-full bg-white dark:bg-[#1A1A1A] border border-gray-200 dark:border-white/5 rounded-full px-6 py-4 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-600 focus:ring-2 focus:ring-black/10 dark:focus:ring-white/20 focus:outline-none transition-all" 
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-800 dark:text-white ml-4">Nom de l'Entreprise</label>
                <input 
                  required 
                  name="company" 
                  type="text" 
                  placeholder="Votre Société" 
                  className="w-full bg-white dark:bg-[#1A1A1A] border border-gray-200 dark:border-white/5 rounded-full px-6 py-4 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-600 focus:ring-2 focus:ring-black/10 dark:focus:ring-white/20 focus:outline-none transition-all" 
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               <div className="space-y-2">
                <label className="text-sm font-bold text-gray-800 dark:text-white ml-4">Email Professionnel</label>
                <input 
                  required 
                  name="email" 
                  type="email" 
                  placeholder="contact@entreprise.com" 
                  className="w-full bg-white dark:bg-[#1A1A1A] border border-gray-200 dark:border-white/5 rounded-full px-6 py-4 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-600 focus:ring-2 focus:ring-black/10 dark:focus:ring-white/20 focus:outline-none transition-all" 
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-800 dark:text-white ml-4">Objectif Principal</label>
                <select 
                  name="objective" 
                  className="w-full bg-white dark:bg-[#1A1A1A] border border-gray-200 dark:border-white/5 rounded-full px-6 py-4 text-gray-900 dark:text-white focus:ring-2 focus:ring-black/10 dark:focus:ring-white/20 focus:outline-none transition-all appearance-none cursor-pointer"
                >
                   <option value="Augmenter les Revenus" className="dark:bg-[#111]">Augmenter les Revenus</option>
                   <option value="Gagner du Temps" className="dark:bg-[#111]">Gagner du Temps</option>
                   <option value="Transformation Digitale" className="dark:bg-[#111]">Transformation Digitale</option>
                   <option value="Autre" className="dark:bg-[#111]">Autre</option>
                </select>
              </div>
            </div>

             <div className="space-y-2">
                <label className="text-sm font-bold text-gray-800 dark:text-white ml-4">Détails du Projet</label>
                <textarea 
                  required 
                  name="message" 
                  rows={4} 
                  placeholder="Décrivez vos besoins actuels..." 
                  className="w-full bg-white dark:bg-[#1A1A1A] border border-gray-200 dark:border-white/5 rounded-[2rem] px-6 py-4 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-600 focus:ring-2 focus:ring-black/10 dark:focus:ring-white/20 focus:outline-none transition-all resize-none"
                ></textarea>
              </div>

            <div className="pt-4 flex flex-col items-center gap-4">
              <CyberButton type="submit" className="w-full md:w-auto min-w-[200px]">
                Envoyer la demande
              </CyberButton>
              <p className="text-xs text-gray-500">
                 En cliquant sur Envoyer, vous acceptez d'être recontacté.
              </p>
            </div>
          </form>
        </motion.div>
      </div>
    </section>
  );
};